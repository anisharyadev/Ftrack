const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const AUTH_KEY = 'YOUR_REAL_MSG91_AUTH_KEY';
const TEMPLATE_ID = 'YOUR_TEMPLATE_ID';

app.post('/send-otp', async (req, res) => {
  const { mobile } = req.body;
  try {
    const response = await fetch('https://control.msg91.com/api/v5/otp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        authkey: AUTH_KEY
      },
      body: JSON.stringify({
        mobile: `91${mobile}`,
        template_id: TEMPLATE_ID
      })
    });

    const data = await response.json();
    res.status(response.status).json(data);
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ type: 'error', message: 'Failed to send OTP' });
  }
});

app.post('/verify-otp', async (req, res) => {
  const { mobile, otp } = req.body;
  try {
    const response = await fetch('https://control.msg91.com/api/v5/otp/verify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        authkey: AUTH_KEY
      },
      body: JSON.stringify({
        mobile: `91${mobile}`,
        otp
      })
    });

    const data = await response.json();
    res.status(response.status).json(data);
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ type: 'error', message: 'Failed to verify OTP' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
